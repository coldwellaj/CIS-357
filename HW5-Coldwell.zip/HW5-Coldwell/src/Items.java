/**
 * Homework 5: JavaFx GUI
 * Student Name: Alex Coldwell
 * Course: CIS 357, Winter 2017
 * Instructor: Dr. Cho
 * Date Finished: 04/05/2.017
 * File Name: Items.java
 */


/**
 * This class is made hold and Item to be sold
 *
 * @author Alexander Coldwell
 */
public class Items {
    public char code;
    public String name;
    public int cost;
    
    public void Items() {
        code = "".charAt(0);
        name = "";
        cost = 0;
    }
}
